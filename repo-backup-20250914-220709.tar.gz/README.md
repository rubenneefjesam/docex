# doge
document generator
[![Python tests](https://github.com/rubenneefjesam/docex/actions/workflows/python-tests.yml/badge.svg)](https://github.com/rubenneefjesam/docex/actions/workflows/python-tests.yml)

