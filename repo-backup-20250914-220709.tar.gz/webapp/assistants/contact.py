# webapp/assistants/contact.py
# Proxy: expose render() from webapp.assistants.home.contact
from .home.contact import render
