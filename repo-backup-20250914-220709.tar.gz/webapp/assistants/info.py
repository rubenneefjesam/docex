# webapp/assistants/info.py
# Proxy: expose render() from webapp.assistants.home.info
from .home.info import render
