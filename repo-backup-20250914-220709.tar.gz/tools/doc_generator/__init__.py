from .docgen import run as docgen

__all__ = ["docgen"]